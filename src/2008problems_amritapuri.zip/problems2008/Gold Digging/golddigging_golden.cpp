#include <cstdio>
#include <iostream>
#include <vector>
#include <ext/numeric>
#include <cstdlib>
#include <set>
#include <cmath>
#include <assert.h>
using namespace std;
using namespace __gnu_cxx;

void generateInput();

double gold[101], b[101], r[101];
double f(int i)
{
	return r[i]*gold[i] * (1-b[i])/b[i];
}
class cmp
{
	public:
	bool operator()(int i, int j)
	{
		double x = f(i) ;
		double y = f(j) ;
		if(x == y) return i < j;
		return x > y;
	}
};

void run()
{
	int n;
	while(scanf("%d",&n) == 1 && n != -1){
		for(int i=0;i<n;i++){
			scanf(" %lf %lf %lf",&b[i],&r[i],&gold[i]);
			assert(0 < b[i] && b[i] <= 100);
			assert(0 <= r[i] && r[i] <= 100);
			assert(1 <= gold[i] && gold[i] <= 100);
			b[i] /= 100.0;
			r[i] /= 100.0;
		}
		double ret = 0;
		double surviving = 1;
		int numDays = 10000;
		int iter = 0;
		set<int> usedPits;
		set<int,cmp> S;
		for(int i=0;i<n;i++)
			S.insert(i);
		while(++iter <= numDays && S.size() > 0){
			int i = *S.begin();
			usedPits.insert(i);
			S.erase(S.begin());
			ret = ret + surviving * (1 - b[i]) * r[i] * gold[i];
			gold[i] = (1 - r[i]) * gold[i];
			if(isnan(f(i))){
				//cerr<<"Ignoring: "<<i<<" "<<f(i)<<endl;
			}
			else S.insert(i);
			surviving = surviving * (1-b[i]);
			if(S.size() == 0){
				//cerr<<"Finishing after: "<<iter<<" iterations"<<endl;
			}
		}
		printf("%.6f\n",ret);
		//cerr<<"Used a total of "<<usedPits.size()<<" out of "<<n<<" pits "<<endl;
	}
}

//Usage: ./a.out [gen|run|check]
int main(int argc, char* argv[])
{
	if(argc > 1 && (argv[1][0]=='g')){
		generateInput();
		return 0;
	}
	if(argc > 1 && argv[1][0]=='r'){
		run();
		return 0;
	}
	run();
	return 0;
}


void sampleCases()
{
	cout<<1<<endl<<50<<" "<<100<<" "<<100<<endl;
	cout<<1<<endl<<50<<" "<<50<<" "<<100<<endl;
	cout<<2<<endl;
	cout<<50<<" "<<100<<" "<<100<<endl;
	cout<<50<<" "<<50<<" "<<100<<endl;
}
void caseOne(){
	//1 gold pit with 50% extraction, 50% machine breakdown: the basic case
	cout<<1<<endl;
	cout<<50<<" "<<50<<" "<<100<<endl;
}
void caseTwo(){
	//1 gold pit, 100% extraction, but machine breaksdown immediately
	cout<<1<<endl;
	cout<<100<<" "<<100<<" "<<100<<endl;
}
void caseThree(){
	//1 gold pit, 0% extraction, but machine does not breakdown (b = 1)
	cout<<1<<endl;
	cout<<1<<" "<<0<<" "<<100<<endl;
}
void caseFour(){
	//Two gold pits, both the same, have to alternate 50% machine, 50% extraction
	cout<<2<<endl;
	cout<<50<<" "<<50<<" "<<50<<endl;
	cout<<50<<" "<<50<<" "<<50<<endl;
}
void caseFive(){
	//Two gold pits, first) machine 99, extraction 1, gold 1  second) machine 1, extraction 99, gold 100
	cout<<2<<endl;
	cout<<99<<" "<<1<<" "<<1<<endl;
	cout<<1<<" "<<99<<" "<<100<<endl;
}
void generateInput()
{
	vector<int> v;
	srand(time(NULL));
	sampleCases();//3 sample cases
	caseOne();
	caseTwo();
	caseThree();
	caseFour();
	caseFive();
	for(int cases = 0; cases < 40; cases++){
		int n = 1 + rand()%100;
		cout<<n<<endl;
		v.push_back(n);
		for(int i=0;i<n;i++){
			int x = rand()%100 + 1;
			int y = rand()%101;
			int z = rand()%100 + 1;
			cout<<x<<" "<<y<<" "<<z<<endl;
		}
	}
	for(int i=0;i<v.size();i++) //cerr<<v[i]<<endl;
	cout<<-1<<endl;
}
