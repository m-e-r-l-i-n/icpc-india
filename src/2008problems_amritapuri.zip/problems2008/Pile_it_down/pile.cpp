#include <iostream>
#include <vector>
#include <string>
#include <map>

using namespace std;

int main() {
  int n;
  int done[2000];
  for (int i =0; i<2000; i++) {
    done[i] = -1;
  }
  done[0]=0;
  int diff =1;
  for (int i = 1; i<=1000; i++) {
    if (done[i]==-1) {
      done[i]=i+diff;
      done[i+diff] = i;
      diff++;
      continue;
    }
  }

  cin>>n;
  for(;n>0;n--) {
    int x,y,pass;
    cin>>x>>y>>pass;
    if(x>y) {
      int temp=x;
      x=y;
      y=temp;
    }
    int ans=0;
    if(done[x]==y) {
      ans=(y-x+pass)*2;
      cout<<"Gita "<<ans<<endl;
    } else {
      int d=min(abs(done[x]-x), y-x);
      ans=1+2*(pass+d);
      cout<<"Sita "<<ans<<endl;
    }
  }
  return 0;
}
