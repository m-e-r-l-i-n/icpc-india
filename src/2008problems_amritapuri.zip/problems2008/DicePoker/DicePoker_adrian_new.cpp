// solution assumes that player 1 knows the first roll of player 2,
// player 2 knows the final roll of player one before he decides which dices to reroll
// player 2 wants to maximize his chances of not losing
// player 1 wants to maximize his chances of winning

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <algorithm>
using namespace std;

int a[5], b[5];
int hands[300][5], l = 0;
int take[5], take2[5];
double best;
int fac[7] = {1, 1, 2, 6, 24, 120, 720};

double getProb(int want[5], int have[5], int cnt) {
	int rolls = 5 - cnt;
	int d[6] = {0};
	double prob = fac[rolls] * pow(6.0, -rolls);
	int i, j;
	for (i=j=0; i<5 && j<cnt; ) {
		if (want[i] < have[j]) {
			if (!rolls)
				return 0;
			--rolls;
			++d[want[i]-1];
			++i;
		}
		else if (want[i] == have[j]) {
			++i;
			++j;
		}
		else
			return 0;
	}
	if (j < cnt)
		return 0;
	while(i < 5) {
		if (!rolls)
			return 0;
		--rolls;
		++d[want[i]-1];
		++i;
	}
	for (int i=0; i<6; ++i)
		prob /= fac[d[i]];
	assert(prob >= 0.0 && prob <= 1.0);
	return prob;
}

double p2_best[300]; // p2_best[i]: best probability to reach a hand with rank <= i
double p2_other[300];

// use backtracking to decide which dices to keep for player 2
void backtrack2(int pos, int cnt, int last_skipped = -1) {
	if (pos == 5) {
		double p2win = 0, p2win_draw = 0;
		// calculate cumulative probability for player 2 to roll hand 0 to i
		for (int i=0; i<l; ++i) {
			p2win += getProb(hands[i], take2, cnt);
			p2win_draw += getProb(hands[i], take2, cnt);
			if (p2win > p2_best[i]) {
				p2_best[i] = p2win;
				p2_other[i] = p2win_draw;
			}
		}
		return;
	}
	backtrack2(pos+1, cnt, b[pos]);
	if (b[pos] != last_skipped) {
		take2[cnt] = b[pos];
		backtrack2(pos+1, cnt+1);
	}
}

// use backtracking to decide which dices to keep for player 1
void backtrack(int pos, int cnt, int last_skipped = -1) {
	if (pos == 5) {
		double res = 0;
		for (int i=0; i<l; ++i) {
			double p1 = getProb(hands[i], take, cnt);
			if (p1 == 0.0)
				continue;
	/*		if (cnt == 4 && take[0] != 1) {
				for (int j=0; j<5; ++j)
					printf("%d ", hands[i][j]);
				printf("p1 = %lf\n", p1);
			}*/
			res += p1 * (1.0 - p2_other[i]);
		}
		if (res > best) {
	/*		for (int i=0; i<cnt; ++i)
				printf("%d ", take[i]);
			printf("cnt = %d, best = %lf\n", cnt, res);*/
			best = res;
		}
		return;
	}
	backtrack(pos+1, cnt, a[pos]);
	if (a[pos] != last_skipped) {
		take[cnt] = a[pos];
		backtrack(pos+1, cnt+1);
	}
}

int main() {
	int tc;
	// generate all possible hands in order of weight
	// 5 of a kind
	for (int i=6; i>=1; --i) {
		for (int j=0; j<5; ++j)
			hands[l][j] = i;
		++l;
	}
	// 4 of a kind
	for (int i=6; i>=1; --i) {
		for (int k=6; k>=1; --k) {
			if (k == i)
				continue;
			for (int j=0; j<4; ++j)
				hands[l][j] = i;
			hands[l][4] = k;
			++l;
		}
	}
	// full house
	for (int i=6; i>=1; --i) {
		for (int j=6; j>=1; --j) {
			if (i == j)
				continue;
			for (int k=0; k<3; ++k)
				hands[l][k] = i;
			for (int k=3; k<5; ++k)
				hands[l][k] = j;
			++l;
		}
	}
	// straight
	for (int i=2; i<=6; ++i)
		hands[l][i-2] = i;
	++l;
	for (int i=1; i<=5; ++i)
		hands[l][i-1] = i;
	++l;
	// 3 of a kind
	for (int i=6; i>=1; --i)
		for (int j=6; j>=1; --j) {
			if (i == j)
				continue;
			for (int k=j-1; k>=1; --k) {
				if (k == i)
					continue;
				for (int h=0; h<3; ++h)
					hands[l][h] = i;
				hands[l][3] = j;
				hands[l][4] = k;
				++l;
			}
		}
	// 2 pair
	for (int i=6; i>=1; --i)
		for (int j=i-1; j>=1; --j)
			for (int k=6; k>=1; --k) {
				if (k == i || k == j)
					continue;
				hands[l][0] = hands[l][1] = i;
				hands[l][2] = hands[l][3] = j;
				hands[l][4] = k;
				++l;
			}
	// pair
	for (int i=6; i>=1; --i)
		for (int j=6; j>=1; --j) {
			if (i == j) continue;
			for (int k=j-1; k>=1; --k) {
				if (i == k)
					continue;
				for (int jj=k-1; jj>=1; --jj) {
					if (i == jj)
						continue;
					hands[l][0] = hands[l][1] = i;
					hands[l][2] = j;
					hands[l][3] = k;
					hands[l][4] = jj;
					++l;
				}
			}
		}
	// rest
	for (int miss=2; miss<6; ++miss) {
		for (int i=1,j=0; i<=6; ++i) {
			if (i == miss) continue;
			hands[l][j++] = i;
		}
		++l;
	}
	for (int i=0; i<l; ++i)
		sort(hands[i], hands[i]+5);
	scanf("%d", &tc);
	assert(tc <= 10);
	while(tc--) {
		for (int i=0; i<5; ++i) {
			scanf("%d", &a[i]);
			assert(a[i] >= 1 && a[i] <= 6);
		}
		sort(a, a+5);
		for (int i=0; i<5; ++i) {
			scanf("%d", &b[i]);
			assert(b[i] >= 1 && b[i] <= 6);
		}
		sort(b, b+5);
		// backtrack over best strategies for player 1
		best = 0.0;
		for (int i=0; i<l; ++i)
			p2_best[i] = -1;
		// first determine best probabilities to reach hand <= i
		backtrack2(0, 0);
		// now find best strategy for player 1
		backtrack(0, 0);
		printf("%.6f\n", floor(best*1e6+0.5)/1e6);
	}
	return 0;
}
