
/**
 *
 * @author sauravshah
 */
import java.io.*;
import java.util.*;

public class PalindromicPath {

    char[][] graph;
    int n;
    String[][] dp;

    String longestPalindrome(char[][] graph) {
        this.graph = graph;
        n = graph.length;
        dp = new String[n][n];
        String ret = solve(0, n - 1);
        return ret;
    }

    String solve(int start, int end) {
        if (start == end) {
            return "";
        }
        if (dp[start][end] != null) {
            return dp[start][end];
        }
        String res = "" + graph[start][end];
        for (int i = start + 1; i < end; ++i) {
            for (int j = end - 1; j >= i; --j) {
                if (graph[start][i] == graph[j][end]) {
                    res = better(res, graph[start][i] + solve(i, j) + graph[j][end]);
                }
            }
        }
        return dp[start][end] = res;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        int kases = Integer.parseInt(in.readLine());
        while (kases-- > 0) {
            int n = Integer.parseInt(in.readLine());
            char[][] ch = new char[n][n];
            for (int i = 0; i < n; ++i) {
                ch[i] = in.readLine().toCharArray();
            }

            System.out.println(new PalindromicPath().longestPalindrome(ch));
        }
    }

    private String better(String a, String b) {
        if (a.length() > b.length()) {
            return a;
        }
        if (a.length() < b.length()) {
            return b;
        }
        if (a.compareTo(b) < 0) {
            return a;
        }
        return b;
    }
}
