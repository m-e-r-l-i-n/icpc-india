
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintStream;

/**
 *
 * @author saurav
 */
public class Minesweeper {

    int n, m;
    boolean[][] shouldHaveFlag;
    char[][] ch;

    boolean solve(char[][] ch) {
        this.ch = ch;
        n = ch.length;
        m = ch[0].length;
        shouldHaveFlag = new boolean[n][m];
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                if (ch[i][j] != 'F') {
                    if (!correct(i, j)) {
                        return false;
                    }
                }
            }
        }

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (ch[i][j] == 'F' && !shouldHaveFlag[i][j]) {
                    return false;
                }
            }
        }
        return true;

    }
    int[] dx = {0, 0, 1, 1, -1, -1, 1, -1};
    int[] dy = {1, -1, 0, -1, 0, 1, 1, -1};

    private boolean correct(int x, int y) {
        int count = 0;
        for (int i = 0; i < 8; ++i) {
            int xx = x + dx[i], yy = y + dy[i];
            if (xx < 0 || yy < 0 || xx >= n || yy >= m) {
                continue;
            }
            if (ch[xx][yy] == 'F') {
                ++count;
                shouldHaveFlag[xx][yy] = true;
            }
        }
        if (count != ch[x][y] - '0') {
            return false;
        }
        return true;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int kases = Integer.parseInt(in.readLine());
        while (kases-- > 0) {
            String[] s = in.readLine().split(" ");
            int n = Integer.parseInt(s[0]);
            int m = Integer.parseInt(s[1]);
            char[][] ch = new char[n][m];
            for (int i = 0; i < n; ++i) {
                ch[i] = in.readLine().toCharArray();
            }
            if (new Minesweeper().solve(ch)) {
                System.out.println("Well done Clark!");
            } else {
                System.out.println("Please sweep the mine again!");
            }
        }

    }
}
