#include <cstdio>
#include <iostream>
#include <vector>
#include <assert.h>
using namespace std;

void printBits(unsigned int x,int end = 32,int start = 0){for(int i = end-1;i>=start;i--) if(x & (1<<i)) cout<<1<<" "; else cout<<0<<" ";}

const int MAXL = 401;
const int MAXC = 10;

void solve();
void check();
void generate();

int main(int argc, char* argv[])
{
	if(argc > 1 && argv[1][0] == 'r'){
		solve();
		return 0;
	}
	if(argc > 1 && argv[1][0] == 'c'){
		check();
		return 0;
	}
	if(argc > 1 && argv[1][0] == 'g'){
		generate();
		return 0;
	}
	solve();
	return 0;
}

void check(){
}


// 1) M = 1, N = 10, all -1 -> 10
// 2) M = 1, N = 9, all -1 -> 9
// 3) M = 1, N = 10, all 0 -> 5
// 4) M = 1, N = 9, all 0 -> 5
// 5) highest degree
// 6) sample case
// 7) Exactly one correct(OC)
// 8) Combination of one correct, highest degree (OC block HD)
// 9) OC Block OC
// 10) HD block HD
// 11) all 0 block all -1 block HD block OC



void caseOne(int n,int start,int m = -1){

	if(m != -1) cout<<m<<" "<<n<<endl;
	for(int i=start;i<start+n-1;i++){
		cout<<-1<<endl;
	}
}
void caseTwo(int n,int start,int m = -1){
	if(m != -1) cout<<m<<" "<<n<<endl;
	for(int i=start;i<start+n-1;i++){
		cout<<-1<<endl;
	}
}
void caseThree(int n,int start,int m = -1){
	if(m != -1) cout<<m<<" "<<n<<endl;
	for(int i=1;i<n;i++) cout<<0<<endl;
}

void caseFour(int n,int start,int m = -1){
	if(m != -1) cout<<m<<" "<<n<<endl;
	for(int i=1;i<n;i++) cout<<0<<endl;
}

void sampleCase(){
	cout<<"2 3"<<endl;
	cout<<"1 4\n2 4 5\n2 4 5\n1 6\n-1"<<endl;
}
#define pb push_back
#define VI vector<int>
void highestDegree(int n,int start,int m = -1){
	if(m != -1) cout<<m<<" "<<n<<endl;
	VI v[11];
	v[1].pb(2);v[1].pb(3);
	v[3].pb(4);v[3].pb(5);
	v[4].pb(8);
	v[5].pb(9); v[5].pb(10);
	v[6].pb(8);v[6].pb(9);v[6].pb(10);
	v[7].pb(8);v[7].pb(9);v[7].pb(10);
	for(int i=1;i<n;i++){
		cout<<v[i].size();
		for(int j=0;j<v[i].size();j++) cout<<" "<<v[i][j]+start-1;
		cout<<endl;
	}
}
void OneCorrect(int n,int start, int m = -1){
	if(m != -1) cout<<m<<" "<<n<<endl;
	VI v[7];
	v[1].pb(4);v[1].pb(5);v[1].pb(6);
	v[2].pb(4);v[2].pb(5);v[2].pb(6);
	v[3].pb(5);v[3].pb(6);
	for(int i=1;i<n;i++){
		cout<<v[i].size();
		for(int j=0;j<v[i].size();j++) cout<<" "<<v[i][j]+start-1;
		cout<<endl;
	}
}
void OCbHD()
{
	int m = 15, n = 20;
	cout<<14<<" "<<20<<endl;
	for(int iter=0;iter<14;iter+=2){
		OneCorrect(7,iter*n+1, -1);
		for(int i=0;i<14;i++) cout<<-1<<endl;
		highestDegree(11, (iter+1)*n+1,-1);
		for(int i=0;i<(iter==12?9:10);i++) cout<<-1<<endl;
	}
}
void OCbOC()
{
	int m = 15, n = 20;
	cout<<14<<" "<<20<<endl;
	for(int iter=0;iter<14;iter++){
		OneCorrect(7,iter*n+1, -1);
		for(int i=0;i<(iter==13?13:14);i++) cout<<-1<<endl;
	}
}

void HDbHD()
{
	int m = 15, n = 20;
	cout<<14<<" "<<20<<endl;
	for(int iter=0;iter<14;iter++){
		highestDegree(11,iter*n+1, -1);
		for(int i=0;i<(iter==13?9:10);i++) cout<<-1<<endl;
	}
}

void generate(){
	caseOne(20,1,1);
	caseTwo(19,1,1);
	caseThree(10,1,1);
	caseThree(9,1,1);
	sampleCase();
	highestDegree(10,1,1);
	OneCorrect(6,1,1);
	OCbHD();
	OCbOC();
	HDbHD();

	int tc = 10;
	srand(time(NULL));
	while(tc--){
		int m = rand()%10 + 6;
		int n = 10;
		cout<<m<<" "<<n<<endl;
		int L = m*n;
		for(int i=0;i+1<L;i++){
			vector<int> chosen;
			for(int j=1;j<=n && i+j<L;j++)
				chosen.push_back(0);
			int cnt = 0;
			for(int j=0;j<chosen.size();j++) if(rand()%2) chosen[j] = 1, cnt++;
			cout<<cnt;
			for(int j=0;j<chosen.size();j++) if(chosen[j]){
				cout<<" "<<j+1+i+1;
			}
			cout<<endl;
		}
	}
	cout<<0<<" "<<0<<endl;
}

int memo[MAXL+1][1<<MAXC];
int L;
int special[MAXL+1];

vector<int> edge[MAXL+1];
int E[MAXL+1][MAXL+1];
int m, n;
int tmask;
int doit(int x, int mask)
{
	if(x==L) return 0;
//	cout<<x+1<<" "; printBits(mask,n); cout<<endl;
	int hash = 0;

	for(int i=1;i<=n && x-i >= 0;i++) if(special[x-i]) {
		hash = (hash<<1)|( (mask&(1<<(i-1)))?1:0);
	}
	int& ret = memo[x][hash];
	if(ret != -1) return ret;
	ret = 0;
	int v;
	for(int i=0;i<edge[x].size();i++){
		v = edge[x][i];
		if(mask & (1<<(x-1-v))){
			ret = max(ret,1 + doit(x+1,  ((mask&(~(1<<(x-1-v)))) << 1) & tmask ));
		}
	}
	ret = max(ret,doit(x + 1 , ((mask<<1)|1) & tmask));
	return ret;
}


void solve()
{
	while(scanf("%d %d",&m,&n)==2 && m > 0){
		assert(1 <= m && m <= 15);
		assert(1 <= n && n <= 20);
		L = m*n;
		tmask = (1<<n) - 1;

		for(int i=0;i<L;i++){
			for(int j=i+n+1;j<L;j++) E[i][j] = 1;
			if(i+1==L) continue;
			int k;
			scanf(" %d",&k);
			special[i] = (k!=-1);
			if(k==-1){
				for(int j=i+1;j<=i+n && j < L;j++) E[i][j] = 1;
			}
			while(k > 0){
				int y;
				scanf("%d",&y);
				y--;
				assert(y < L);
				E[i][y] = 1;
				k--;
			}
		}
		
		for(int i=0;i<L;i++){
			int spcount = 0;
			for(int j=i;j<i+n && j < L;j++) spcount += special[j];
			assert(spcount <= 10);
		}
		for(int k=0;k<L;k++)
			for(int i=0;i<L;i++)
				for(int j=0;j<L;j++)
					if(E[i][k] && E[k][j]) E[i][j] = 1;
		for(int i=0;i<L;i++)
			for(int j=0;j<(1<<MAXC);j++) memo[i][j] = -1;
		for(int i=0;i<L;i++) for(int j=i+1;j<=i+n && j < L;j++) if(!E[i][j]) edge[j].push_back(i);
		for(int i=0;i<L;i++) for(int j=0;j<L;j++) E[i][j] = 0;

		for(int i=0;i<L;i++){
//			cout<<i+1<<" -> ";
			for(int j=0;j<edge[i].size();j++){
//				cout<<edge[i][j]+1<<" ";
			}
//			cout<<endl;
		}

		int ret = doit(0, 0);
		ret = L - ret;
		cout<<ret<<endl;
//		cout<<endl<<endl<<endl;
		for(int i=0;i<L;i++) edge[i].clear();
	}
}
