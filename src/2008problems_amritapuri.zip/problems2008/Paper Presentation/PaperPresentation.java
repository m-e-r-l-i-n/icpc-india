/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author saurav
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.*;

public class PaperPresentation {

    int n;
    List<List<Integer>> groups;
    boolean[][] beat;
    long[] dp;
    int[] deps;
    int ssize = 0;
    long MOD = 10000000000000000L;
    long[][] CC;
    List<Integer> s;

    long solve(boolean[][] beat) {
        this.beat = beat;
        n = beat.length;
        boolean[][] w = new boolean[n][n];
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                w[i][j] = beat[i][j];
            }
        }
        for (int k = 0; k < n; ++k) {
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    w[i][j] = (w[i][j]) || (w[i][k] && w[k][j]);
                }
            }
        }
        for (int i = 0; i < n; ++i) {
            if (w[i][i]) {
                return 0;
            }
        }
        CC = new long[50][50];
        for (long[] a : CC) {
            Arrays.fill(a, -1);
        }
        groups = new ArrayList<List<Integer>>();
        boolean[] v = new boolean[n];

        for (int i = 0; i < n; ++i) {
            if (!v[i]) {
                List<Integer> ss = new ArrayList<Integer>();
                dfs(i, v, ss);
                if (ss.size() > n / 2) {
                    return 0;
                }
                groups.add(ss);
            }
        }
        deps = new int[11];
        dp = new long[1 << 11];
        int gr = groups.size();
        long res = 0;

        long[] noOfWays = new long[gr];
        int[] noOfScientists = new int[gr];
        int g = 0;
        for (List<Integer> s : groups) {

            Arrays.fill(deps, 0);
            int i = -1;
            for (Integer si : s) {
                ++i;
                int j = -1;
                for (Integer sj : s) {
                    ++j;
                    if (beat[si][sj]) {
                        deps[j] |= 1 << i;
                    }
                }
            }
            Arrays.fill(dp, -1);
            this.s = s;
            ssize = s.size();
            noOfWays[g] = (solve(0));
            noOfScientists[g++] = (s.size());
        }


        for (int i = 0; i < (1 << gr); ++i) {
            int count = 0;
            for (int j = 0; j < gr; ++j) {
                if ((i & (1 << j)) != 0) {
                    count += noOfScientists[j];
                }
            }
            long ret1 = 1;
            long ret2 = 1;
            int count1 = 0;
            int count2 = 0;
            if (count == n / 2) {
                for (int j = 0; j < gr; ++j) {
                    if ((i & (1 << j)) == 0) {
                        ret1 = (ret1 * noOfWays[j]) % MOD;
                        count1 += noOfScientists[j];
                        ret1 = (ret1 * choose(count1, noOfScientists[j])) % MOD;

                    } else {
                        ret2 = (ret2 * noOfWays[j]) % MOD;
                        count2 += noOfScientists[j];
                        ret2 = (ret2 * choose(count2, noOfScientists[j])) % MOD;
                    }
                }
                res = (res + (ret1 * ret2) % MOD) % MOD;
            }

        }
        return res % MOD;


    }

    long choose(int N, int C) {
        if (CC[N][N] != -1) {
            return CC[N][C];
        }
        if (C > N) {
            return 0;
        }
        if (N == C) {
            return 1;
        }
        if (C == 0) {
            return 1;
        }

        long ret = 0;
        ret = (ret + choose(N - 1, C - 1)) % MOD;
        ret = (ret + choose(N - 1, C)) % MOD;
        return CC[N][C] = ret;

    }

    long solve(int mask) {
        if (dp[mask] != -1) {
            return dp[mask];
        }
        if (mask == (1 << ssize) - 1) {
            return 1;
        }
        int i = -1;
        long res = 0;

        for (int j = 0; j < ssize; ++j) {
            ++i;
            if ((mask & (1 << i)) != 0) {
                continue;
            }
            if ((mask & deps[i]) != deps[i]) {
                continue;
            }
            res = (res + solve(mask | 1 << i)) % MOD;

        }
        return dp[mask] = res;
    }

    void dfs(int index, boolean[] v, List<Integer> s) {
        s.add(index);
        v[index] = true;
        for (int i = 0; i < n; ++i) {
            if (beat[index][i] || beat[i][index]) {
                if (!v[i]) {
                    dfs(i, v, s);
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int kases = Integer.parseInt(in.readLine());
        while (kases-- > 0) {
            int n = Integer.parseInt(in.readLine());
            boolean[][] b = new boolean[2 * n][2 * n];
            for (int i = 0; i < b.length; ++i) {
                String s = in.readLine();
                for (int j = 0; j < b.length; ++j) {
                    b[i][j] = (s.charAt(j) == 'Y');
                }
                if (b[i][i]) {
                    System.err.println(i + " " + kases);
                }
            }
            System.out.println(new PaperPresentation().solve(b));
        }
    }
}
