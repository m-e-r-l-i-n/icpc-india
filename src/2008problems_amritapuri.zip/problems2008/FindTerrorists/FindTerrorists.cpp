#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <assert.h>
using namespace std;
#define FOR(i,x) for(int i=0; i<x; i++)
#define FORE(i,x,y) for(int i=x; i<y; i++)
map<int,int>isPrime;
int main() {
  int n;
  cin>>n;
  vector<int>pr;
  FORE(i,2,10001){
    bool isPr = true;
    for(int j=2;j*j<=i;j++) {
      if(i%j ==0)isPr = false;
    }
    if(isPr) {
      pr.push_back(i);
      isPrime[i]=1;
    }
  }
  for(;n>0;n--) {
    int l,h;
    cin>>l>>h;
    assert(l>0 && l<=10000);
    assert(h>=l && h<=10000);
    set<int>st;
    set<int>::iterator it;
    for (int i=0; i<pr.size();i++) {
      long long p = pr[i];
      for (int j=2;p<=h;j++) {
        if(isPrime[j] && p>=l)st.insert(p);
	p=p*pr[i];
      }
    }
    for(it=st.begin();it!=st.end();it++) {
      if (it==st.begin())
        cout<<(*it);
      else
        cout<<" "<<(*it);
    }
    if (st.size()==0)cout<<-1<<endl;
    else cout<<endl;
  }
  return 0;
}
