#include <cstdio>
#include <iostream>
#include <vector>
#include <ext/numeric>
#include <cstdlib>
#include <set>
#include <assert.h>
using namespace std;
using namespace __gnu_cxx;

typedef long long int lint;
typedef vector<lint> VI;
typedef vector<VI> VVI;

const lint MOD = 10007;

void generateInput()
{
	//first 50
	//last 50
	//100 random cases in [10^8 -> 10^9 - 50]
	//100 random cases in [50 10^8)

	set<int> S;
	int first = 50, second = 50, third = 100, fourth = 50, last = 50;
	lint maxCase = 1000000000, a = 10000, b = 9LL*maxCase/10;

	srand(time(NULL));
	//[0, first) , [first, a) , [a, b) , [b, maxCase-last+1) [maxCase-last+1 maxCase]
	//
	for(int i=0;i<first;i++) {
		cout<<i<<endl;
		S.insert(i);
	}
	for(int i=0;i<second;i++){
		lint mod = (a - first);
		int x = first + rand()%mod;
		cout<<x<<endl;
		S.insert(x);
	}
	for(int i=0;i<third;i++){
		lint mod = (b-a);
		int x = a + rand()%mod;
		cout<<x<<endl;
		S.insert(x);
	}
	for(int i=0;i<fourth;i++){
		lint mod = maxCase - last + 1 - b;
		int x = b + rand()%mod;
		cout<<x<<endl;
		S.insert(x);
	}
	for(int i=maxCase-last+1;i<=maxCase;i++) {
		cout<<i<<endl;
		S.insert(i);
	}
	cout<<-1<<endl;
	assert(S.size() == first + second + third + fourth + last);
}

lint myPower(lint x, lint n)
{
	if(n==0) return 1;
	if(n%2) return x * myPower(x,n-1) % MOD;
	lint y = myPower(x , n/2);
	return y*y%MOD;
}

VVI operator*(VVI A, VVI B)
{
	VVI ret(2,VI(2,0));
	for(int i=0;i<2;i++)
		for(int j=0;j<2;j++){
			for(int k=0;k<2;k++){
				ret[i][j] = (ret[i][j] + A[i][k]*B[k][j])%MOD;
			}
		}
	return ret;
}

lint solve(lint n)
{
	if(n==0) return 1;
	if(n==1) return 4;
	VVI A(2, VI(2,0));
	A[0][0] = 2; A[0][1] = 2;
	A[1][0] = 1; A[1][1] = 0;
	VVI B = __power(A, n);

	//B*([2 1]Transpose) = [F(n+1), F(n)]
	lint x = (B[0][0] * 2 + B[0][1] * 1)%MOD;
	lint y = (B[1][0] * 2 + B[1][1] * 1)%MOD;
	lint ret = ( (2*n+2)%MOD*x + (4*n+8)%MOD*y ) % MOD;
	lint invOf12 = myPower(12, MOD-2);
	ret = ret * invOf12 % MOD;
	return ret;
}

void run()
{
	int n;
	int MAXN = 1000000000;
	while(scanf(" %d",&n) == 1 && n >= 0){
		assert(n <= MAXN);
		cout<<solve(n)<<endl;
	}
}

const lint MAX_CHECK = 10000;
lint F[MAX_CHECK];
void check()
{
	F[0] = 1;
	F[1] = 2;
	for(int i=0;i<MAX_CHECK;i++){
		if(i%100000 == 0) cout<<"Checked until: "<<i<<endl;
		if(i >= 2) F[i] = (F[i-1] + F[i-2])*2%MOD;
		lint slow = 0;
		for(int j=0;j<=i;j++) slow = (slow + F[j] * F[i-j])%MOD;
		lint fast = solve(i);
		if(fast != slow){
			cout<<"Failed Test for n = "<<i<<endl;
			cout<<"Fast = "<<fast<<" , Slow = "<<slow<<endl;
			assert(fast == slow);
		}
	}
	cout<<"ALL Checks done ! MAX_CHECK = "<<MAX_CHECK - 1 << endl;
}

//Usage: ./a.out [gen|run|check]
int main(int argc, char* argv[])
{
	if(argc > 1 && (argv[1][0]=='g')){
		generateInput();
		return 0;
	}
	if(argc > 1 && argv[1][0]=='r'){
		run();
		return 0;
	}
	if(argc > 1 && argv[1][0]=='c'){
		check();
		return 0;
	}
	run();
	return 0;
}
